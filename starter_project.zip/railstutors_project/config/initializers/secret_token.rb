# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
CourseProject::Application.config.secret_token = '9b485391af86de1df518f2154817653fb0b5a8650668ebfdc2206124a93a379ec20c789777e165e026f37c5f7891cb4512eb5d2d35ab1ef035093527f8c95a83'
