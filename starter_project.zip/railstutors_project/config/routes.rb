CourseProject::Application.routes.draw do
  root to: "main#index"
end
